Build with:
  latexmk -pdf main.tex

Requires a TeX distribution with the achemso class (standard in TeX Live / MiKTeX).
Produces main.pdf.
